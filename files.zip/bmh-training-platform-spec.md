# BMH Training Platform Build Spec

A lightweight Thinkific replacement for internal BMH Group VA training. Supabase backend, React frontend, Vimeo embed for video.

## Stack

Supabase for auth, Postgres, Row Level Security, storage (certificates, assignment uploads)
React with Vite, TypeScript, Tailwind, shadcn/ui
TanStack Query for data fetching
React Router for routing
react-pdf or pdf-lib for certificate generation
Vimeo embedded player (domain-locked privacy)
Vercel for hosting

## Core Concepts

Users have one or more roles. Roles grant access to one or more courses. Courses contain ordered modules. Modules contain ordered lessons. Lessons are either video, quiz, or assignment. Quizzes have questions with configurable randomization and pass thresholds. A lesson can require a prerequisite lesson (with optional quiz pass score) before it unlocks. Completing all required lessons in a course issues a certificate.

## Roles

Three system roles baked in:

owner: Jarrad, full admin access, manage everything
admin: optional second tier, manage courses and users but not billing
learner: default for VAs and team members, can only view courses assigned to their role groups

Beyond system roles, the role_groups table lets Jarrad create custom groups like "Appointment Setters," "Lead Managers," "Acquisitions" and assign courses to those groups. A user can belong to multiple groups.

## Database Schema

All tables use uuid primary keys with gen_random_uuid() defaults. created_at and updated_at timestamps default to now().

### profiles
Extends Supabase auth.users. One row per auth user.
- id (uuid, pk, references auth.users.id)
- email (text)
- full_name (text)
- avatar_url (text, nullable)
- system_role (text, check in ('owner', 'admin', 'learner'), default 'learner')
- status (text, check in ('active', 'invited', 'suspended'), default 'invited')
- created_at, updated_at

### role_groups
Custom role groups created by admins.
- id (uuid, pk)
- name (text, unique) for example "Appointment Setters"
- description (text, nullable)
- created_at, updated_at

### user_role_groups
Many to many between profiles and role_groups.
- user_id (uuid, references profiles.id, on delete cascade)
- role_group_id (uuid, references role_groups.id, on delete cascade)
- primary key (user_id, role_group_id)

### courses
- id (uuid, pk)
- title (text)
- description (text, nullable)
- thumbnail_url (text, nullable)
- is_published (boolean, default false)
- certificate_enabled (boolean, default true)
- certificate_template_id (uuid, nullable, references certificate_templates.id)
- sort_order (integer, default 0)
- created_at, updated_at

### course_access
Grants a role group access to a course.
- id (uuid, pk)
- course_id (uuid, references courses.id, on delete cascade)
- role_group_id (uuid, references role_groups.id, on delete cascade)
- unique (course_id, role_group_id)

Owners and admins see all courses implicitly via RLS.

### modules
- id (uuid, pk)
- course_id (uuid, references courses.id, on delete cascade)
- title (text)
- description (text, nullable)
- sort_order (integer)
- created_at, updated_at

### lessons
- id (uuid, pk)
- module_id (uuid, references modules.id, on delete cascade)
- title (text)
- description (text, nullable)
- lesson_type (text, check in ('video', 'quiz', 'assignment'))
- video_url (text, nullable) Vimeo or YouTube embed URL
- video_duration_seconds (integer, nullable)
- quiz_id (uuid, nullable, references quizzes.id)
- assignment_id (uuid, nullable, references assignments.id)
- prerequisite_lesson_id (uuid, nullable, references lessons.id) the lesson that must be completed (and quiz passed if applicable) before this one unlocks
- is_required_for_completion (boolean, default true)
- sort_order (integer)
- created_at, updated_at

### quizzes
- id (uuid, pk)
- title (text)
- description (text, nullable)
- passing_score (integer, default 80) percentage 0 to 100
- randomize_questions (boolean, default true)
- randomize_answers (boolean, default true)
- questions_per_attempt (integer, nullable) if set, pulls this many randomly from the pool. Null means show all
- max_attempts (integer, nullable) null means unlimited
- retake_cooldown_hours (integer, default 0)
- show_correct_answers_after (text, check in ('never', 'after_pass', 'always'), default 'after_pass')
- created_at, updated_at

### questions
- id (uuid, pk)
- quiz_id (uuid, references quizzes.id, on delete cascade)
- question_text (text)
- question_type (text, check in ('true_false', 'single_choice', 'multi_select'))
- explanation (text, nullable) shown after answering if configured
- points (integer, default 1)
- sort_order (integer) baseline order, randomization overrides at attempt time
- created_at, updated_at

### answer_options
- id (uuid, pk)
- question_id (uuid, references questions.id, on delete cascade)
- option_text (text)
- is_correct (boolean, default false)
- sort_order (integer)
- created_at

For true_false questions seed two options ("True" and "False") with is_correct set appropriately.

### assignments
- id (uuid, pk)
- title (text)
- instructions (text)
- submission_type (text, check in ('file_upload', 'text', 'url'))
- requires_review (boolean, default true)
- created_at, updated_at

### assignment_submissions
- id (uuid, pk)
- assignment_id (uuid, references assignments.id)
- user_id (uuid, references profiles.id)
- lesson_id (uuid, references lessons.id)
- submission_text (text, nullable)
- submission_url (text, nullable)
- submission_file_path (text, nullable) supabase storage path
- status (text, check in ('submitted', 'approved', 'needs_revision'), default 'submitted')
- reviewer_notes (text, nullable)
- reviewed_by (uuid, nullable, references profiles.id)
- reviewed_at (timestamptz, nullable)
- submitted_at (timestamptz, default now())

### user_lesson_progress
Tracks completion of video and assignment lessons. Quiz progress is derived from user_quiz_attempts.
- id (uuid, pk)
- user_id (uuid, references profiles.id, on delete cascade)
- lesson_id (uuid, references lessons.id, on delete cascade)
- completed_at (timestamptz, default now())
- unique (user_id, lesson_id)

### user_quiz_attempts
- id (uuid, pk)
- user_id (uuid, references profiles.id, on delete cascade)
- quiz_id (uuid, references quizzes.id, on delete cascade)
- lesson_id (uuid, references lessons.id) which lesson wrapped this quiz
- score (integer) percentage 0 to 100
- passed (boolean)
- question_order (jsonb) array of question ids in the order served for this attempt
- answer_orders (jsonb) object mapping question_id to array of answer_option_ids in the order served
- responses (jsonb) object mapping question_id to array of selected answer_option_ids
- started_at (timestamptz, default now())
- completed_at (timestamptz, nullable)

### user_course_resume
One row per user per course tracking where to resume.
- user_id (uuid, references profiles.id, on delete cascade)
- course_id (uuid, references courses.id, on delete cascade)
- last_lesson_id (uuid, references lessons.id)
- updated_at (timestamptz, default now())
- primary key (user_id, course_id)

### certificates
- id (uuid, pk)
- user_id (uuid, references profiles.id)
- course_id (uuid, references courses.id)
- issued_at (timestamptz, default now())
- pdf_path (text) supabase storage path
- certificate_number (text, unique) human readable like BMH-2026-0001
- unique (user_id, course_id)

### certificate_templates
Optional per course branding.
- id (uuid, pk)
- name (text)
- background_image_path (text, nullable)
- body_html (text) with merge fields like {{full_name}}, {{course_title}}, {{completion_date}}, {{certificate_number}}
- created_at, updated_at

### invites
Used for inviting team members before they create an account.
- id (uuid, pk)
- email (text)
- role_group_ids (uuid array) groups to assign on acceptance
- system_role (text, default 'learner')
- token (text, unique) random secure token
- invited_by (uuid, references profiles.id)
- accepted_at (timestamptz, nullable)
- expires_at (timestamptz, default now() + interval '14 days')
- created_at

### audit_log
Lightweight activity feed for admin dashboard.
- id (uuid, pk)
- user_id (uuid, nullable, references profiles.id)
- action (text) for example 'lesson_completed', 'quiz_passed', 'certificate_issued', 'user_invited'
- entity_type (text)
- entity_id (uuid)
- metadata (jsonb)
- created_at

## Row Level Security Policies

Enable RLS on every table. Key policies:

profiles: users can read their own row and rows of users in shared role groups. Owners and admins can read and update all rows.

courses: learners can select a course only if it's published AND they belong to a role_group that has a course_access entry for it. Owners and admins can select all and do all writes.

modules and lessons: inherit access from parent course. Learners can select only if they can select the parent course.

user_lesson_progress and user_quiz_attempts: users can insert and select their own rows. Owners and admins can select all.

assignment_submissions: learners can insert and select their own. Owners and admins can select all and update status, reviewer_notes, reviewed_by, reviewed_at.

certificates: users can select their own. Owners and admins can select all.

All writes on courses, modules, lessons, quizzes, questions, answer_options, role_groups, course_access, invites restricted to system_role in ('owner', 'admin').

## Key Server Side Functions (Postgres)

### fn_lesson_is_unlocked(user_id uuid, lesson_id uuid) returns boolean
Returns true if the lesson has no prerequisite, OR the prerequisite lesson is completed, AND if the prerequisite is a quiz lesson, the user's best attempt passed.

### fn_course_completion_percent(user_id uuid, course_id uuid) returns integer
Count of required lessons completed divided by total required lessons times 100. Quiz lessons count as complete when the user has a passing attempt.

### fn_issue_certificate_if_eligible(user_id uuid, course_id uuid)
Checks if course is 100% complete and certificate_enabled is true. If so, generates a certificate_number, renders the PDF via edge function, uploads to storage, and inserts the certificates row. Idempotent via unique constraint.

### Trigger: after insert on user_lesson_progress and user_quiz_attempts
Calls fn_issue_certificate_if_eligible for the affected course. Also updates user_course_resume.last_lesson_id.

## Frontend Routes

Public:
/login
/invite/:token (accept invite, set password, create profile)
/forgot-password

Learner:
/dashboard (my courses, in progress and completed)
/courses/:courseId (course overview, module and lesson list with lock icons)
/lessons/:lessonId (video player OR quiz runner OR assignment view)
/certificates (my earned certificates with download buttons)
/profile

Admin (system_role in ('owner', 'admin')):
/admin (dashboard with team progress heatmap)
/admin/courses (list, create, edit, publish)
/admin/courses/:courseId/edit (manage modules, lessons, prerequisites)
/admin/quizzes/:quizId/edit (questions, options, settings)
/admin/users (list team members, invite new, assign role groups)
/admin/role-groups (CRUD role groups, assign courses)
/admin/submissions (pending assignment reviews)
/admin/reports (per course, per user, per quiz breakdowns)

## Key UI Components

LessonGate wraps any lesson route. Calls fn_lesson_is_unlocked first. If locked, shows "Complete [prerequisite name] to unlock this lesson" with a link back.

QuizRunner handles the whole attempt flow. On mount, creates a user_quiz_attempts row with question_order and answer_orders generated per the quiz randomization settings. Persists responses jsonb on each answer so a mid quiz refresh restores state from that attempt. On submit, calculates score server side via an RPC to prevent client tampering, then shows pass or fail screen with retake button respecting cooldown and max_attempts.

VideoPlayer accepts a Vimeo or YouTube URL, detects provider, embeds with privacy params (Vimeo: dnt=1, YouTube: youtube-nocookie.com). Marks lesson complete when playback reaches 90%.

AdminProgressTable shows all users as rows, all courses as columns, cells show percent complete with color coding (red under 25, yellow 25 to 75, green above). Click a cell for user x course drilldown.

CertificateViewer renders the PDF inline with a download button.

## Edge Functions (Supabase)

generate-certificate: given user_id and course_id, renders HTML from the certificate_template, converts to PDF via @react-pdf/renderer or Puppeteer, uploads to storage, returns signed URL.

send-invite-email: called when creating an invite row. Sends email via Resend or Postmark with the /invite/:token link.

score-quiz-attempt: called from QuizRunner on submit. Reads responses, compares to correct answers, writes score and passed, triggers certificate check.

## Invite Flow

1. Admin enters email, selects role_groups and optional system_role, clicks invite
2. invites row created, send-invite-email fires
3. Recipient clicks link, lands on /invite/:token
4. Token validated (not expired, not accepted), email shown pre-filled
5. User sets password, Supabase auth.users row created, profile row created, user_role_groups rows created, invites.accepted_at set
6. Redirect to /dashboard

## Build Phases for Claude Code

Phase 1 foundation
- Initialize Vite React TypeScript project, install deps, configure Tailwind and shadcn
- Set up Supabase project, apply schema migrations, enable RLS
- Auth: login, forgot password, invite acceptance flow
- Protected routes with role check hook

Phase 2 content model and learner experience
- Admin: create course, module, lesson CRUD (video lessons only for now)
- Learner: dashboard, course detail page, video lesson playback, progress tracking
- Resume where you left off

Phase 3 quizzes
- Admin: quiz and question CRUD with all three question types
- Randomization logic in QuizRunner
- Pass threshold and retake logic
- Prerequisite unlock system

Phase 4 roles and access control
- role_groups CRUD
- course_access assignment UI
- RLS policies fully locked down
- Invite flow end to end

Phase 5 certificates and reporting
- Certificate template system
- PDF generation edge function
- Admin progress dashboard and reports
- Audit log feed

Phase 6 assignments (optional, do last)
- Assignment lesson type
- Submission UI and file upload
- Reviewer workflow

## Environment Variables

VITE_SUPABASE_URL
VITE_SUPABASE_ANON_KEY
SUPABASE_SERVICE_ROLE_KEY (edge functions only)
RESEND_API_KEY (edge functions only)
VITE_APP_URL (used in invite emails)

## Seed Data for Testing

After migrations, seed:
- 1 owner profile (Jarrad)
- 2 role groups: "Appointment Setters", "Lead Managers"
- 1 sample course "Appointment Setter Foundations" with 2 modules, 1 video lesson, 1 quiz lesson
- 1 sample quiz with 2 true_false, 2 single_choice, 1 multi_select questions
- course_access entry granting Appointment Setters access to that course

## Notes and Guardrails

No HTML form tags in React, use onClick handlers (learned from prior artifact work)
All scoring done server side via RPC, never trust client calculated scores
Signed URLs for video if you move off Vimeo later
Keep the admin UI functional not fancy, this is internal
No em dashes anywhere in UI copy or seeded content
Company name is BMH Group, not BMH Group KC
